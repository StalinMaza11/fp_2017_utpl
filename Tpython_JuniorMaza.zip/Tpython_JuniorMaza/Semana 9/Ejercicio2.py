# Arreglos unidimensionales
lista = [11,22,43,14]
i = 0
j = 0
suma = 0
for i in range(0,4):
    print ("Posicion",j,"- Valor",lista[i])
    suma = lista[i] + suma
print(suma)
input()
