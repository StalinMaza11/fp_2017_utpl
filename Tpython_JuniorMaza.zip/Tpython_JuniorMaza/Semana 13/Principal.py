# Importamos el modulo desde otra clase
import Trabajador

# Variables
nombre = "Luis"
apellido = "Romero"
cedula = "115545545"
edad = 40
sueldo_neto = 500.2

Trabajador.generar_recibo(nombre, apellido, cedula, edad, sueldo_neto)
   
input()
