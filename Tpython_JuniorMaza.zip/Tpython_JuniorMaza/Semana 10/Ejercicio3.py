# Arreglo bidimencional
arreglo = [[1, 2, 3], [11, 22, 33]]
# Bucle para recorrer el arreglo
for i in range(1):
    for j in range(1):
        print(arreglo[0]),
        print(arreglo[1])
	
	
input()
