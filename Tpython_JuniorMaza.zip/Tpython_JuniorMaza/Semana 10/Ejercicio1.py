# Imprime arreglo bidimensional 
# Arreglos bidimensionales
arreglo = [[0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]]
# Bucle para recorrer los arreglos
for i in range(0, 4):
	for j in range(0, 4):
		print(arreglo[i][j])

input()
