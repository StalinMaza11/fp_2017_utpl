# Imprime arreglo bidimensional en blanco

arreglo = [0,0,0,0]
# Bucle para recorrer el arreglo
for i in range( 4):
	print(arreglo)
	print (" ")



input()
