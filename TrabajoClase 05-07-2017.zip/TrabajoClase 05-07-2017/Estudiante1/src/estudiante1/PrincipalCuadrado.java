/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiante1;

import java.util.Scanner;
/**
 *
 * @author Junior Maza
 */
public class PrincipalCuadrado {
    public static void main(String[] args){
       Scanner e = new Scanner (System.in);
       for (int i = 1; i <= 5;i++){
           Cuadrado c = new Cuadrado ();
           System.out.printf("\n==========>>Ingrese lado:");
           int lado = e.nextInt();
           c.agregar_lado(lado);
           c.calcular_area();
           c.calcular_perimetro();
           System.out.printf("El cuadrado con lado:%d\n\tArea:%d\n\tPerimetro:%d\n",c.obtener_lado(),c.calcular_area(),c.calcular_perimetro() );
           System.out.printf("_________________________________________________");
           
       } 
       
        
    }
    
}
