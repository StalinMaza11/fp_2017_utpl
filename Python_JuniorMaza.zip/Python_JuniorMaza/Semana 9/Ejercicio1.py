# Arreglo unidimensional
lista = [0,0,0,0,0]
i = 0
# bucle for
for numero in lista:
    print ("Posicion",lista[0],"- Valor",i)
    lista[0] = lista[0] + 1

input()
