# Declaracion de variables
suma = 0
promedio = 0
materias=["Programacion", "Base de datos", "Contabilidad", "Biologia"]
notas=[0,0,0,0,0,0,0]
# Proceso e ingreso de datos
for i in range (4):
    notas[i] = input("Ingrese la nota de "+ materias[i])
    suma = suma + int(notas[i])

for i in range (4):
    print("Nota de la materia "+materias[i]+"fue de "+notas[i])
promedio = (float(suma / 4))
# salida de Rasultados
print("El promedio de las notas es: "+ str(promedio))
# Comparar de notas 
if (promedio > 80) :
     print("Sobresaliente\n")
if (promedio < 80 and promedio > 60):
     print("Bueno\n")
if (promedio <= 60):
     print("Regular\n")

input()
