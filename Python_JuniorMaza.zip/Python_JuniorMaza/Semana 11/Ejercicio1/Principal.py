from Operaciones import Operaciones1
op = Operaciones1()
print("Ingrese los valores para las operaciones")
a = int(input("===>"))
b = int(input("===>"))
tipo = int(input("Escoja la operacion a realizar:\n1.-Suma\n2.-Resta\n3.-Multiplicacion\n4.-Division\n-->"))
op.ope(tipo,a,b)








