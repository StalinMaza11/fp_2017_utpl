# Listas
notas = [[7, 7, 8], [9,8,10],[10,10,3]]
suma = 0
# Bucle para recorrer el arreglo
for i in range(0, 3):
	for k in range(0, 3):
		if (i > k):
			suma = suma + notas[i][k]
# Presentar la suma
print("La suma es: %d\t" %suma)	
