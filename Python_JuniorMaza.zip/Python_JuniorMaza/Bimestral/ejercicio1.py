# Ejercicio 1 
import random

jugadores=int(input("Ingrese numero de jugadores: "))
sumatoria=[]
lanzamientoJugadores=[]
jugador=[]
suma=0
mayor=0
ganador=0

for i in range(0,jugadores):
	for j in range(0,4):
		numero=random.randint(1,6)
		jugador.append(numero)
		suma=suma+numero
		pass
	sumatoria.append(suma)
	lanzamientoJugadores.append(jugador)
	jugador=[]
	suma=0
	pass

for x in range(0,len(sumatoria)):
	if sumatoria[x]>mayor:
		ganador=x
		mayor=sumatoria[x]

		pass
	pass

for x in range(0,len(lanzamientoJugadores)):
	print("Jugador %d: %s = %d"%(x+1,lanzamientoJugadores[x],sumatoria[x]))
	pass
print("Ganador Jugador ",ganador+1)
input()
