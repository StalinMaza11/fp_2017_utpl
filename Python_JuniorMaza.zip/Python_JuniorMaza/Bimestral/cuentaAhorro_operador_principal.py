# Clase
class CuentaAhorro():
	
	def __init__(self, nombre,edad,cedula,saldo):
		self.nombre = nombre
		self.edad = edad
		self.cedula = cedula
		self.saldo = saldo
	# Metodo
	def setNombre(self,nombre):
		self.nombre=nombre
		pass
	def getNombre(self):
		return self.nombre
	
	def setEdad(self,edad):
		self.edad=edad
		pass
	def getEdad(self):
		return self.edad

	def setCedula(self,cedula):
		self.cedula=cedula
		pass
	def getCedula(self):
		return self.cedula

	def setSaldo(self,saldo):
		self.saldo=saldo
		pass
	def getSaldo(self):
		return self.saldo

	def toString(self):
		return print("")
# Clase
class OperadorCuenta():
	"""docstring for OperadorCuenta"""
	def __init__(self, listaCuentas):
		self.listaCuentas = listaCuentas[:]
		self.totalCuentas = 0
	def setListaCuentas(self,listaCuentas):
		self.listaCuentas=listaCuentas[:]
		pass
	def getListaCuentas(self):
		return listaCuentas

	def calcularSaldos(self):
		for x in range(0,len(self.listaCuentas)):
			self.totalCuentas=self.totalCuentas+self.listaCuentas[x].getSaldo()
			pass
		pass

	def impresionCuentas(self):
		print("Nombre\t\t Cedula\t\t\t Saldo",sep="\t")
		for x in range(0,len(self.listaCuentas)):
			print("%s\t\t %s\t\t %.2f"% (self.listaCuentas[x].getNombre(),self.listaCuentas[x].getCedula(),self.listaCuentas[x].getSaldo()),sep="\t")
			pass
		print("Total cuentas:\t\t\t\t %.2f"% (self.totalCuentas))
		pass

c1= CuentaAhorro("Marco",20,"1105295313",10)
c2= CuentaAhorro("Maria",18,"123457789",10)
c3= CuentaAhorro("Luis",18,"1234523489",10)
c4= CuentaAhorro("Jose",18,"123456679",10)

lista=[c1,c2,c3,c4]

operador= OperadorCuenta(lista)
operador.calcularSaldos()

operador.impresionCuentas()

input()
