# Ingreso de Datos
a = input("Ingrese valor de a:")
a = int(a)
b = input("Ingrese valor de b:")
b = int(b)
c = input("Ingrese valor de c:")
c = int(c)
# Casting (Cambiar variables de int a float)
float(int(a))
float(int(b))
float(int(c))
# Formula 
x= 10/a + b - 3 * c
# Presentación de la formula resuelta
print ("El valor es:\n%.2f " %(x))
