a = input("Ingrese valor de a:")
a = int(a)
b = input("Ingrese valor de b:")
b = int(b)
c = input("Ingrese valor de c:")
c = int(c)
x= 10/a + b - 3 * c
print ("El valor es:\n%.2f " %(x))

