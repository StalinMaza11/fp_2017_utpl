# Ingreso de Datos
edad = input("Ingrese su edad: ")
edad = int(edad)
estatura = input ("Ingrese su estatura: ")
estatura = float(estatura)
# Presentación de los datos ingresados
print ("Mi edad es :", edad , "\n""y Mi altura es :", estatura)
