# Manejo de condicionales
valor = 11
# Inicio Ciclo if
if valor >= 7 and valor <= 10:
	print("Aprobado con: ",valor)
else:
	print("Reprobado con:" ,valor)
