# Manejo de condicionales
valor = 9
# Inicio Ciclo if
if valor >=10:
	print ("Aprobado con ",valor)
else:
	print ("Reprobado con ", valor)	
