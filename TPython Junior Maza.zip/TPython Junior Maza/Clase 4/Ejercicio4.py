cont = 1
suma = 0
limite = input ("Ingrese Limite:")
limite = int (limite)
while cont <= limite:
    suma = suma + cont
    cont = cont + 1
print ("La suma total es:\n\t\n", suma)
