suma = 0
bandera = True
while bandera:
    valor = input ("Ingrese el valor a sumar:")
    valor = int (valor)
    suma = suma + valor
    m = input ("Ingrese -1 para salir:")
    m = int (m)
    if m == -1:
        bandera = False
print ("Valores sumados igual a: \n" , suma)
