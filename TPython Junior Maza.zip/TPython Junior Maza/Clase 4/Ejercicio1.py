# Inicializacion de variable
cont = 1
# Inicio de ciclo while
while cont <= 5:
    print ("Valor", cont)
    cont = cont + 1
