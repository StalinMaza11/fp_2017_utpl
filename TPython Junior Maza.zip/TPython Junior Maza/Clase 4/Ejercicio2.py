# Ingreso de Datos
print ("Ingrese sus nombres:")
nombre = str (input())
# cambiar a letras mayusculas
nombre = nombre.upper()
print ("Ingrese sus apellidos:")
apellidos = str (input())
# cambiar a letras minusculas
apellidos = apellidos.lower()
edad = input ("Ingrese su edad:")
edad = int (edad)
print ("Ingrese ciudad:")
ciudad = str (input())
# cambiar a letras mayusculas
ciudad = ciudad.upper()
año = 2017 - edad
print ("\n Datos personales \n Nombres: %s \n Apellidos: %s \n Ano de Nacimiento: %d \n Edad: %d \n Ciudad: %s" %(nombre, apellidos , año, edad, ciudad))
