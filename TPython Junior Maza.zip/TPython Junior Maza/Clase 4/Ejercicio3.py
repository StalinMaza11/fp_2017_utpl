suma = 0
bandera = True
cadena_final = ""
cadena = ""
while bandera:
    valor = input ("Ingrese el valor a sumar:")
    valor = int (valor)
    suma = suma + valor
    m = input ("Ingrese -1 para salir:")
    m = int (m)
    if m == -1:
        bandera = False
    cadena =( "Valor ingresado: %d\n" %(valor))
    cadena_final = cadena_final + cadena
    
print ("%s" %(cadena_final))
print ("Valores sumados igual a:", suma)
