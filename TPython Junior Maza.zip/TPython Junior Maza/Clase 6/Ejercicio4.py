# Inicializacion de variables
suma1 = 0
suma2 = 0
cadena = ""
# Encabezado
cadena = cadena + format("\n %s \t \t %s" %("Valor","Total"))
# Inicio del ciclo for
for i in range(1,11):
	suma1 = suma1 + i
	auxiliar = i + 10
	suma2 = suma2 + auxiliar
	cadena = cadena + format("\n %d \t \t %d" %(i,auxiliar))
# Presentacion de resultados
cadena = cadena + format("\n %d \t \t %d" %(suma1,suma2))
print(cadena)
