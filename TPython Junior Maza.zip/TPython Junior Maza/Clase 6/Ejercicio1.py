# Ciclo For
for d in range(1,10):
	print(d)
