valor = 0
# Ingreso de Datos
print ("Ingrese de que forma quiere la cadena:\n")
print ("Pulse 1 si quiere la cadena vertical || Pulse 2 si quiere la cadena horizontal: ")
valor = int(input())
# Inicio Ciclo for
for cont in range (1,1):
	if valor == 1:
		print("\n" ,cont)
	if valor == 2:
		print(cont)
