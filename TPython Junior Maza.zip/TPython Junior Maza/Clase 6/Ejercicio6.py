# Inicialiar variable tipo string
cadena = " "
# inicio Ciclo for 
for cont in range(1,11):
	cadena = cadena + format("\n %d \t \t %d " %(cont, cont + 10))
# Presentacion de cadena	
print(cadena)
