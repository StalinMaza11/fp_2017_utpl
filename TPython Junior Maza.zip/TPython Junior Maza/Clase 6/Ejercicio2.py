# Inicializar variable tipo string
cadena = ""
# Encabezado de la tabla
cadena = cadena + format("%s \t \t %s \n" %("Valor","Total"))
# Inicio del Ciclo for
for d in range(1,10):
	cadena = cadena + format("\n %d \t \t %d"%(d,d+10))
# Presentar Cadena
print(cadena)

