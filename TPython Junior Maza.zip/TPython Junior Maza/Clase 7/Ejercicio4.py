cont = 1
par = 0
impar = 0
cadena1 = ""
cadena2 = ""
# Inicio de proceso
while True:
    if cont % 2 == 0:
        cadena1 = cadena1 + "\t" + str(cont)+ "\n"
        par = par + cont
        
    else:
        cadena2 = cadena2 + "\t" + str(cont)+ "\n"
        impar = impar + cont
    cont = cont + 1

    if cont > 10:
        break
print ("La suma de pares\n", cadena1, "\nEs igual a\n", par, "\n\nLa suma de impares\n", cadena2, "\nEs igual a\n", impar)
