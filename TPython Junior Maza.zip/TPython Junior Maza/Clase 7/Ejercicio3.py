# Switch no existe en Python el programa se realiza con if e elif
print ("Ingrese el día")
dia = input()
print("Ingrese el mes")
cont = input()
print("Ingrese el año")
año = input ()
cadena = ""
# Anidacion de if e elif
if cont == 1:
     cadena = "Enero"
    
elif cont == 2:
     cadena = "Febrero"

elif cont == 3:
     cadena = "Marzo"
    
elif cont == 4:
     cadena = "Abril"

elif cont == 5:
     cadena = "Mayo"
     
elif cont == 6:
     cadena = "Junio"

elif cont == 7:
     cadena = "Julio"

elif cont == 8:
     cadena = "Agosto"

elif cont == 9:
     cadena = "Septiembre"

elif cont == 10:
     cadena = "Octubre"

elif cont == 11:
     cadena = "Noviembre"

elif cont == 12:
     cadena = "Diciembre"
else:
    print("Elija un mes en los numeros del rango del 1 al 12:")

print ("La fecha ingresada es:\n\t", dia, "de", cadena, "del", año)

