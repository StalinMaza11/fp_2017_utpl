cont = 1
# En python no hay el ciclo du while por lo tanto usare el while true
while True:
    print (cont)
    cont = cont + 1
    # El if es para terminar el ciclo while 
    if cont >= 10:
        break 

