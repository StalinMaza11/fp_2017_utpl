cont = 5
# Python no existe el ciclo Switch entonces se anidan ciclos If
if cont == 1:
    print("Dia\n\tLunes")
elif cont == 2:
    print("Dia\n\tMartes")
elif cont == 3:
    print("Dia\n\tMiercoles")
elif cont == 4:
    print("Dia\n\tJueves")
elif cont == 5:
    print("Dia\n\tViernes")
else:
    print("Ninguna de las anteriores")
