Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:42:59) [MSC v.1500 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> nombre = "Junior"
>>> apellido = "Maza"
>>> print nombre, apellido
Junior Maza
>>> 